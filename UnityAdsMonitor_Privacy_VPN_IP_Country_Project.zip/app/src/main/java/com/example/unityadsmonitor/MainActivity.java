package com.example.unityadsmonitor;

import android.app.Activity;
import android.os.Bundle;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.content.SharedPreferences;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.json.JSONObject;
import android.widget.*;
import android.view.View;
import com.unity3d.ads.*;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAdsShowOptions;

public class MainActivity extends Activity {
    EditText gameId, placementId; CheckBox testMode; TextView vpn, vpnDetails, ipCountry, stats;
    int loaded=0, shown=0, completed=0, clicks=0, errors=0;
    SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("local_stats", MODE_PRIVATE);
        loaded=prefs.getInt("loaded",0); shown=prefs.getInt("shown",0);
        completed=prefs.getInt("completed",0); clicks=prefs.getInt("clicks",0);
        errors=prefs.getInt("errors",0);
        gameId=findViewById(R.id.gameId); placementId=findViewById(R.id.placementId);
        testMode=findViewById(R.id.testMode); vpn=findViewById(R.id.vpn); vpnDetails=findViewById(R.id.vpnDetails); ipCountry=findViewById(R.id.ipCountry); stats=findViewById(R.id.stats);
        findViewById(R.id.init).setOnClickListener(v -> initAds());
        findViewById(R.id.showAd).setOnClickListener(v -> showAd());
        findViewById(R.id.reset).setOnClickListener(v -> {loaded=shown=completed=clicks=errors=0; update();});
        updateVpn();
        loadIpCountry();
    }

    void initAds() {
        String id=gameId.getText().toString().trim();
        if(id.isEmpty()){ Toast.makeText(this,"Game ID দিন",Toast.LENGTH_SHORT).show(); return; }
        UnityAds.initialize(this,id,testMode.isChecked(),new IUnityAdsInitializationListener(){
            public void onInitializationComplete(){ Toast.makeText(MainActivity.this,"Unity Ads initialized",Toast.LENGTH_SHORT).show(); }
            public void onInitializationFailed(UnityAds.UnityAdsInitializationError e,String m){ errors++; update(); }
        });
    }

    void showAd() {
        String p=placementId.getText().toString().trim();
        if(p.isEmpty()){Toast.makeText(this,"Ad Unit / Placement ID দিন",Toast.LENGTH_SHORT).show();return;}
        UnityAds.load(p,new IUnityAdsLoadListener(){
            public void onUnityAdsAdLoaded(String placementId){ loaded++; update();
                UnityAds.show(MainActivity.this,placementId,new UnityAdsShowOptions(),new IUnityAdsShowListener(){
                    public void onUnityAdsShowStart(String id){shown++;update();}
                    public void onUnityAdsShowClick(String id){clicks++;update();}
                    public void onUnityAdsShowComplete(String id,UnityAds.UnityAdsShowCompletionState s){if(s==UnityAds.UnityAdsShowCompletionState.COMPLETED)completed++;update();}
                    public void onUnityAdsShowFailure(String id,UnityAds.UnityAdsShowError e,String m){errors++;update();}
                });
            }
            public void onUnityAdsFailedToLoad(String id,UnityAds.UnityAdsLoadError e,String m){errors++;update();}
        });
    }

    void loadIpCountry() {
        new Thread(() -> {
            try {
                URL u = new URL("https://ipwho.is/");
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(7000); c.setReadTimeout(7000);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder b = new StringBuilder(); String line;
                while((line=r.readLine())!=null) b.append(line);
                JSONObject j = new JSONObject(b.toString());
                String ip = j.optString("ip","Unknown");
                String country = j.optString("country","Unknown");
                String city = j.optString("city","Unknown");
                String isp = j.optString("connection", "Unknown");
                runOnUiThread(() -> ipCountry.setText(
                    "Public IP: "+ip+"\\nCountry: "+country+"\\nCity: "+city+"\\nNetwork: "+isp));
            } catch(Exception e) {
                runOnUiThread(() -> ipCountry.setText("Public IP / Country: unavailable"));
            }
        }).start();
    }

    void update(){stats.setText("Ads Loaded: "+loaded+"\nAds Shown: "+shown+"\nAds Completed: "+completed+"\nAd Clicks: "+clicks+"\nAd Errors: "+errors);}
    @Override protected void onResume(){ super.onResume(); updateVpn(); }

    void updateVpn(){
        ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        Network n=cm.getActiveNetwork(); boolean v=false;
        NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
        if(c!=null) v=c.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
        vpn.setText("VPN: "+(v?"Connected":"Not connected"));
        if (v && c != null) {
            StringBuilder d = new StringBuilder();
            d.append("VPN Details\\n");
            d.append("Transport: VPN\\n");
            d.append("Validated: ").append(c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)).append("\\n");
            d.append("Internet capability: ").append(c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)).append("\\n");
            d.append("Metered: ").append(c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) ? "No" : "Yes").append("\\n");
            vpnDetails.setText(d.toString());
        } else {
            vpnDetails.setText("VPN Details\\nNo active VPN transport detected.");
        }
    }
}
