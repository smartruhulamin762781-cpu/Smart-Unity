# Unity Ads Monitor — Privacy + VPN IP/Country

Includes:
- VPN Connected/Disconnected
- VPN transport/network details
- Public IP
- IP geolocation country and city
- Network/ISP information when provided by the lookup service
- No GPS/fine/coarse location permission
- Local ad statistics

Note: IP/country lookup sends the public IP to the selected geolocation service. This is not GPS tracking, but the lookup provider necessarily receives the IP. Unity Ads is not intentionally given this lookup data by the app.
